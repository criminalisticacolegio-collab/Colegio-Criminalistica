import { sanityClient } from 'sanity:client';

export const GET = async ({ url }) => {
  const email = url.searchParams.get('email');

  if (!email) {
    return new Response(JSON.stringify({ error: 'Email is required' }), { status: 400 });
  }

  try {
    const matriculado = await sanityClient.fetch(
      `*[_type == "matriculado" && email == $email][0]`,
      { email }
    );

    return new Response(JSON.stringify({ exists: !!matriculado }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: 'Sanity fetch failed' }), { status: 500 });
  }
};
