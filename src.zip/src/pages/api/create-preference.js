import { MercadoPagoConfig, Preference } from 'mercadopago';

export const POST = async ({ request }) => {
  const body = await request.json();
  const { amount, email, title } = body;

  const client = new MercadoPagoConfig({ 
    accessToken: process.env.MP_ACCESS_TOKEN || '' 
  });

  const preference = new Preference(client);

  try {
    const result = await preference.create({
      body: {
        items: [
          {
            title: title || 'Cuota Social Colegio',
            unit_price: Number(amount),
            quantity: 1,
            currency_id: 'ARS'
          }
        ],
        payer: {
          email: email
        },
        back_urls: {
          success: `${new URL(request.url).origin}/success`,
          failure: `${new URL(request.url).origin}/matriculados`,
          pending: `${new URL(request.url).origin}/matriculados`
        },
        auto_return: 'approved',
      }
    });

    return new Response(JSON.stringify({ id: result.id, init_point: result.init_point }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    console.error('Error MP:', error);
    return new Response(JSON.stringify({ error: 'Error al crear la preferencia' }), {
      status: 500
    });
  }
};
