import React from 'react';

const PaymentButton = ({ amount, text = "Pagar ahora" }) => {
  const handlePayment = async () => {
    try {
      console.log(`Iniciando pago por: $${amount}`);
      
      // Simulación de llamada a la API de MercadoPago
      // En una integración real:
      /*
      const response = await fetch('/api/mercadopago/create-preference', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount, title: text })
      });
      const { init_point } = await response.json();
      window.location.href = init_point;
      */

      alert(`Redirigiendo a MercadoPago para abonar $${amount.toLocaleString('es-AR')}. (Simulación)`);
    } catch (error) {
      console.error('Error en el pago:', error);
    }
  };

  return (
    <button 
      onClick={handlePayment}
      style={{
        background: '#009EE3', // Color oficial MercadoPago
        color: 'white',
        border: 'none',
        padding: '12px 24px',
        borderRadius: '8px',
        fontWeight: 'bold',
        cursor: 'pointer',
        fontSize: '1rem',
        transition: 'background 0.3s'
      }}
      onMouseOver={(e) => e.target.style.background = '#007eb5'}
      onMouseOut={(e) => e.target.style.background = '#009EE3'}
    >
      {text}
    </button>
  );
};

export default PaymentButton;
