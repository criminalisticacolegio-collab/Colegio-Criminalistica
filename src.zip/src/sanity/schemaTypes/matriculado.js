import { defineField, defineType } from 'sanity'

export default defineType({
    name: 'matriculado',
    title: 'Matriculados',
    type: 'document',
    fields: [
        defineField({
            name: 'numeroMatricula',
            title: 'Número de Matrícula',
            type: 'string',
            description: 'Ej: MP-1024',
            validation: Rule => Rule.required(),
        }),
        defineField({
            name: 'email',
            title: 'Email (Primary Key)',
            type: 'string',
            validation: Rule => Rule.required().email(),
        }),
        defineField({
            name: 'nombreCompleto',
            title: 'Nombre Completo',
            type: 'string',
            validation: Rule => Rule.required(),
        }),
        defineField({
            name: 'estado',
            title: 'Estado',
            type: 'string',
            options: {
                list: [
                    { title: 'Activo', value: 'Activo' },
                    { title: 'Suspendido', value: 'Suspendido' },
                    { title: 'Baja', value: 'Baja' },
                ],
            },
            validation: Rule => Rule.required(),
        }),
        defineField({
            name: 'jurisdiccion',
            title: 'Jurisdicción',
            type: 'reference',
            to: [{ type: 'jurisdiccion' }],
            description: 'Crucial para los filtros',
            validation: Rule => Rule.required(),
        }),
        defineField({
            name: 'especialidad',
            title: 'Especialidad',
            type: 'reference',
            to: [{ type: 'especialidad' }],
            description: 'Crucial para los filtros',
            validation: Rule => Rule.required(),
        }),
    ],
    preview: {
        select: {
            title: 'nombreCompleto',
            subtitle: 'numeroMatricula',
        },
    },
})
