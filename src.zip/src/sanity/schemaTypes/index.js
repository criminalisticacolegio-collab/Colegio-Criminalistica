import institucionalConfig from './institucionalConfig';
import matriculadosConfig from './matriculadosConfig';
import padronConfig from './padronConfig';
import capacitacionConfig from './capacitacionConfig';
import tribunalConfig from './tribunalConfig';
import gestionConfig from './gestionConfig';
import noticiasConfig from './noticiasConfig';
import bibliotecaConfig from './bibliotecaConfig';
import tramitesConfig from './tramitesConfig';
import contactoConfig from './contactoConfig';
import aspirante from './aspirante';
import jurisdiccion from './jurisdiccion';
import especialidad from './especialidad';
import matriculado from './matriculado';
import arancelProfesional from './arancelProfesional';
import configuracionCobros from './configuracionCobros';

export const schemaTypes = [
  institucionalConfig,
  matriculadosConfig,
  padronConfig,
  capacitacionConfig,
  tribunalConfig,
  gestionConfig,
  noticiasConfig,
  bibliotecaConfig,
  tramitesConfig,
  contactoConfig,
  aspirante,
  jurisdiccion,
  especialidad,
  matriculado,
  arancelProfesional,
  configuracionCobros,
];